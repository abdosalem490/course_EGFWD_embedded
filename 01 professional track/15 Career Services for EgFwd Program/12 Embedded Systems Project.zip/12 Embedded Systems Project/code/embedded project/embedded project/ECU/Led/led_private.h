/*
 * led_private.h
 *
 * Created: 28/09/2022 6:06:14 am
 *  Author: abdo
 */ 


#ifndef LED_PRIVATE_H_
#define LED_PRIVATE_H_





#endif /* LED_PRIVATE_H_ */