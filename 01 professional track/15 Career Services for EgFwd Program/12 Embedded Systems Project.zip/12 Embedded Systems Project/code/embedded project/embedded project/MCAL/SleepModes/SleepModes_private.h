/*
 * SleepModes_private.h
 *
 * Created: 23/09/2022 6:51:02 pm
 *  Author: abdo
 */ 


#ifndef SLEEPMODES_PRIVATE_H_
#define SLEEPMODES_PRIVATE_H_





#endif /* SLEEPMODES_PRIVATE_H_ */