/*
 * Timer0_config.h
 *
 * Created: 25/09/2022 6:58:44 pm
 *  Author: abdo
 */ 


#ifndef TIMER0_CONFIG_H_
#define TIMER0_CONFIG_H_



#endif /* TIMER0_CONFIG_H_ */