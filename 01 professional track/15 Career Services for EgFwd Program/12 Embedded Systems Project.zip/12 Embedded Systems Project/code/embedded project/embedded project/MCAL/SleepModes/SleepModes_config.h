/*
 * SleepModes_config.h
 *
 * Created: 23/09/2022 6:50:52 pm
 *  Author: abdo
 */ 


#ifndef SLEEPMODES_CONFIG_H_
#define SLEEPMODES_CONFIG_H_





#endif /* SLEEPMODES_CONFIG_H_ */