/*
 * GPIO_config.h
 *
 * Created: 24/09/2022 12:33:29 am
 *  Author: abdo
 */ 


#ifndef GPIO_CONFIG_H_
#define GPIO_CONFIG_H_





#endif /* GPIO_CONFIG_H_ */